from src.confidence_fusion.policy import fuse_confidence
from src.routing.router import route_anatomy

class UnifiedFetalBiometryPipeline:
    def __init__(self, backend, *, routing_enabled=False, allow_quality_review_route=True):
        self.backend = backend
        self.routing_enabled = bool(routing_enabled)
        self.allow_quality_review_route = bool(allow_quality_review_route)

    def _measure(self, route, scan):
        if route == "head_biometry":
            return self.backend.measure_head(scan)
        if route == "abdomen_biometry":
            return self.backend.measure_abdomen(scan)
        if route == "femur_biometry":
            return self.backend.measure_femur(scan)
        raise ValueError(f"Unsupported route: {route}")

    def run(self, scan):
        plane = self.backend.detect_plane(scan)
        quality = self.backend.assess_quality(scan)
        route = route_anatomy(
            plane,
            quality,
            routing_enabled=self.routing_enabled,
            allow_quality_review=self.allow_quality_review_route,
        )

        result = {
            "pipeline_version": "phase8_v2",
            "plane": plane,
            "quality": quality,
            "route": route,
            "measurement": None,
            "fusion": None,
        }

        if route["route_status"] != "routed":
            return result

        measurement = self._measure(route["route"], scan)
        result["measurement"] = measurement

        fusion = fuse_confidence(plane, quality, measurement)
        result["fusion"] = fusion
        result["measurement_discarded"] = fusion["discard_measurement"]
        return result
